/******************************************************************************
* Project Name		: Bootloadable Blinking LED
* File Name			: main.c
* Version 			: 1.0
* Device Used		: CY8C4245AXI-483
* Software Used		: PSoC Creator 3.1
* Compiler    		: ARMGCC 4.8.4, ARM RVDS Generic, ARM MDK Generic
* Related Hardware	: CY8CKIT-049-42xx PSoC 4 Prototyping Kit 
*
********************************************************************************
* Copyright (2015), Cypress Semiconductor Corporation. All Rights Reserved.
********************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress)
* and is protected by and subject to worldwide patent protection (United
* States and foreign), United States copyright laws and international treaty
* provisions. Cypress hereby grants to licensee a personal, non-exclusive,
* non-transferable license to copy, use, modify, create derivative works of,
* and compile the Cypress Source Code and derivative works for the sole
* purpose of creating custom software in support of licensee product to be
* used only in conjunction with a Cypress integrated circuit as specified in
* the applicable agreement. Any reproduction, modification, translation,
* compilation, or representation of this software except as specified above 
* is prohibited without the express written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. 
*
* Use of this Software may be limited by and subject to the applicable Cypress
* software license agreement. 
*******************************************************************************/

/******************************************************************************
*                           THEORY OF OPERATION
* This is a blinking LED project. A PWM component drives the pin to blink the 
* LED at regular intervals. This project contains a bootloadable component so 
* that it can be bootloaded into PSoC 4 which has a bootloader already programmed 
* into it.
* Default UART Port Configuration for bootloading the PSoC 4 in CY8CKIT-049-42xx
* Baud Rate : 115200 bps
* Data Bits : 8
* Stop Bits : 1
* Parity    : None*/

#include <project.h>
//#include <device.h>

/* Macro for a black space on the 7-segment LCD */
#define BLANK (16u)

/* Macro for scrolling length */
#define SCROLL_LENGTH (14u)
/* Macro for initial scrolling value */
#define INITIAL_VALUE (0u)
/* Define the numbers used for scrolling the 4-digit display */
#define SCROLL0 (0u)
#define SCROLL1 (1u)
#define SCROLL2 (2u)
#define SCROLL3 (3u)
#define SCROLL4 (4u)
#define DIGIT0 (0u)
#define DIGIT1 (1u)
#define DIGIT2 (2u)
#define DIGIT3 (3u)
#define DIGIT4 (4u)
/* Define the loop delay */
#define LOOP_DELAY (512u)
int main()
{
    uint8 flag=0;
    /* This variable is used to index the character array */
    uint8 index = 0;
    /* Array of scrolling numbers including blank spaces to improve visibility */
    uint8 numbers[] = {BLANK, BLANK, BLANK, BLANK,BLANK,1, 2, 3, 4, 5, 6, 7, 8, 9, 0, BLANK, BLANK, BLANK,BLANK,};
    /* Starts the Segment LCD Component */
    LCD_Seg_Start();
	PWM_Start();
	for(;;)
    {
        /* The PSoC 4 is put into Sleep Mode as the PWM component is used to 
		blink the LED */
	//	CySysPmSleep();
        for(index = INITIAL_VALUE; index < SCROLL_LENGTH; index++)
        {
            /* Print the numbers on the LCD glass */
            LCD_Seg_Write7SegDigit_0(numbers[index + SCROLL4], DIGIT0);
            LCD_Seg_Write7SegDigit_0(numbers[index + SCROLL3], DIGIT1);
            LCD_Seg_Write7SegDigit_0(numbers[index + SCROLL2], DIGIT2);
            LCD_Seg_Write7SegDigit_0(numbers[index + SCROLL1], DIGIT3);
            LCD_Seg_Write7SegDigit_0(numbers[index + SCROLL0], DIGIT4);
            LCD_Seg_WritePixel(LCD_Seg_T1,LCD_Seg_PIXEL_STATE_INVERT);
            LCD_Seg_WritePixel(LCD_Seg_T3,LCD_Seg_PIXEL_STATE_INVERT); 
            LCD_Seg_WritePixel(LCD_Seg_T4,LCD_Seg_PIXEL_STATE_ON);
            Pin_1_7_Write(flag);
            
            flag=~flag;
            /* Give delay for a visible scrolling */
            CyDelay(LOOP_DELAY);
        }
    }
}




